alert('Are you ready to learn the ninja way');
